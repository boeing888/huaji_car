CREATE TRIGGER test_count_for_agent
  AFTER UPDATE
  ON test
  FOR EACH ROW
  begin
update agent set agent_num = agent_num + '1'
where agent_id=test.agent_id;
end;

