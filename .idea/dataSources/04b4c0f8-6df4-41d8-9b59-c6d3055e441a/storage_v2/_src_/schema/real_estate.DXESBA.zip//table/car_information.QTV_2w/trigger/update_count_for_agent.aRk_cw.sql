CREATE TRIGGER update_count_for_agent
  BEFORE INSERT
  ON car_information
  FOR EACH ROW
  begin
update agent
set agent_num = agent_num + '1'
where agent_id=new.agent_id;
end;

